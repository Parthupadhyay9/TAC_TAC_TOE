function setup() {
  createCanvas(400, 400);
}

function draw() {

    
   background(220);
  
    rect( 200,200,100,100 );
  
  
  // rect( 380,mouseY,10,80);
 // rect( 10,180,10,80);
 // rect( 200, 200, 10, 10);
    
  
}