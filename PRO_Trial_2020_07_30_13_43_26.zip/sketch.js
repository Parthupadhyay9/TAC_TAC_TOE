function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('black');
  rect(380, mouseY, 10, 80);
  rect(10, 170, 10, 80);
  rect(195, 195, 10, 10);
}